//
//  Contraview.swift
//  coreML-nanostarter
//
//  Created by Alumno on 19/10/23.
//

import SwiftUI

struct Contraview: View {
    var body: some View {
        Text("Después podrás recuperar tu contraseña.")
    }
}

struct Contraview_Previews: PreviewProvider {
    static var previews: some View {
        Contraview()
    }
}
