//
//  SubirReceta.swift
//  coreML-nanostarter
//
//  Created by Alumno on 19/10/23.
//

import SwiftUI

struct SubirRecetaView: View {
    var body: some View {
        Text("Aqui podrás subir recetas propias para todo el mundo.")
    }
}

struct SubirRecetaView_Previews: PreviewProvider {
    static var previews: some View {
        SubirRecetaView()
    }
}
