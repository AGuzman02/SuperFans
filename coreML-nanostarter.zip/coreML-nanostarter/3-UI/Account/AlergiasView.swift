//
//  AlergiasView.swift
//  coreML-nanostarter
//
//  Created by Alumno on 12/10/23.
//

import SwiftUI

struct AlergiasView: View {
    
    var body: some View {
        
        VStack{
            Text("Aqui podrás marcar tus alergias.")
        }
        
    }
}

struct AlergiasView_Previews: PreviewProvider {
    static var previews: some View {
        AlergiasView()
    }
}
