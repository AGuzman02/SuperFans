//
//  Classification.swift
//  coreML-starter
//
//  
//

struct Classification: Decodable {
    // TODO: replace with the name of your keys from mydata.json and some default values
    var label: String = "Banana"
    var emoji: String = "🍌"
    var video: String = "tDuruX7XSac?si=D1p6UeugrACLF9ww"
}
