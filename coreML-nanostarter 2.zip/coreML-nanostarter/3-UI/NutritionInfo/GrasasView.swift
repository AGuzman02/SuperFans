//
//  GrasasView.swift
//  coreML-nanostarter
//
//  Created by Alumno on 02/11/23.
//

import SwiftUI

struct GrasasView: View {
    var body: some View {
        Text("Grasas")
    }
}

struct GrasasView_Previews: PreviewProvider {
    static var previews: some View {
        GrasasView()
    }
}
