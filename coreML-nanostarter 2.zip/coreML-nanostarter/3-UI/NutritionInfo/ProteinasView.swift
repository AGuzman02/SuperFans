//
//  ProteinasView.swift
//  coreML-nanostarter
//
//  Created by Alumno on 02/11/23.
//

import SwiftUI

struct ProteinasView: View {
    var body: some View {
        Text("Proteinas")
    }
}

struct ProteinasView_Previews: PreviewProvider {
    static var previews: some View {
        ProteinasView()
    }
}
