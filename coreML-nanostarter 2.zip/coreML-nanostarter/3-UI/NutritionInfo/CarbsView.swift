//
//  CarbsView.swift
//  coreML-nanostarter
//
//  Created by Alumno on 02/11/23.
//

import SwiftUI

struct CarbsView: View {
    var body: some View {
        Text("Carbohidratos")
    }
}

struct CarbsView_Previews: PreviewProvider {
    static var previews: some View {
        CarbsView()
    }
}
