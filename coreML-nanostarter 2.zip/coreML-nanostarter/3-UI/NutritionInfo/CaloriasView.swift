//
//  CaloriasView.swift
//  coreML-nanostarter
//
//  Created by Alumno on 02/11/23.
//

import SwiftUI

struct CaloriasView: View {
    var body: some View {
        Text("Calorias")
                .font(.title)
                .fontWeight(.bold)
                .padding(.bottom, 20)
    }
}

struct CaloriasView_Previews: PreviewProvider {
    static var previews: some View {
        CaloriasView()
    }
}
