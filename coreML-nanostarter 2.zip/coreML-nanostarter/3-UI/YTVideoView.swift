//
//  YTVideoView.swift
//  coreML-nanostarter
//
//  Created by Alumno on 03/11/23.
//

import SwiftUI

struct YTVideoView: View {
    var body: some View {
        
    }
}

struct YTVideoView_Previews: PreviewProvider {
    static var previews: some View {
        YTVideoView()
    }
}
